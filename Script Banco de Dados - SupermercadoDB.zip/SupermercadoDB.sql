create database SUPERMERCADODB
GO
USE SUPERMERCADODB
GO
------------------------------------------------------------------------------------------------------------------
CREATE TABLE Produtos (
    CodigoProduto VARCHAR(15) PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Categoria VARCHAR(50) NOT NULL,
    QuantidadeEstoque INT NOT NULL,
    Preco DECIMAL(10, 2) NOT NULL,
    DataCadastro DATE DEFAULT GETDATE()
    );

select * from produtos;

------------------------------------------------------------------------------------------------------------------
CREATE TABLE Vendas (
    CodigoVenda INT IDENTITY(1,1) PRIMARY KEY,
    DataVenda DATETIME NOT NULL,
    ValorTotal DECIMAL(10, 2) NOT NULL,
    FormaPagamento VARCHAR(50) NOT NULL
    );

    ------------------------------------------------------------------------------------------------------------------
    CREATE TABLE ItensVendas (
    CodigoItem INT IDENTITY(1,1) PRIMARY KEY,
    CodigoVenda INT NOT NULL,
    CodigoProduto VARCHAR(15) NOT NULL,
    Quantidade INT NOT NULL CHECK (Quantidade > 0),
    PrecoUnitario DECIMAL(10, 2) NOT NULL,
    Total AS (Quantidade * PrecoUnitario),

    CONSTRAINT FK_CodigoVenda_Vendas 
        FOREIGN KEY (CodigoVenda) REFERENCES Vendas(CodigoVenda) ON DELETE CASCADE,
    
    CONSTRAINT FK_CodigoProdutos_Produtos 
        FOREIGN KEY (CodigoProduto) REFERENCES Produtos(CodigoProduto)
    );

   ------------------------------------------------------------------------------------------------------------------

INSERT INTO Produtos (CodigoProduto, Nome, Categoria, QuantidadeEstoque, Preco, DataCadastro)
VALUES 
('ALM001', 'Arroz Branco 5kg', 'Alimentos', 50, 24.90, '2026-05-19'),
('ALM002', 'Feijão Carioca 1kg', 'Alimentos', 80, 8.50, '2026-05-19'),
('BEB001', 'Refrigerante Cola 2L', 'Bebidas', 90, 9.00, '2026-05-19'),
('LMP001', 'Sabão em Pó 1kg', 'Produtos de limpeza', 40, 15.50, '2026-05-19'),
('HIG001', 'Creme Dental 90g', 'Produtos de Higiene', 100, 4.00, '2026-05-19');


INSERT INTO Vendas (DataVenda, ValorTotal, FormaPagamento)
VALUES 
(GETDATE(), 42.90, 'PIX'),                 
(GETDATE(), 23.50, 'Cartão de Crédito'),   
(GETDATE(), 8.50, 'Dinheiro');

INSERT INTO ItensVendas (CodigoVenda, CodigoProduto, Quantidade, PrecoUnitario)
VALUES 
(1, 'ALM001', 1, 24.90), 
(1, 'BEB001', 2, 9.00),  

(2, 'LMP001', 1, 15.50),  
(2, 'HIG001', 2, 4.00),    

(3, 'ALM002', 1, 8.50);

SELECT * FROM Vendas;

------------------------------------------------------------------------------------------------------------------

CREATE VIEW NotaFiscal AS
 
SELECT
    V.CodigoVenda,
    V.DataVenda,
    V.FormaPagamento,
 
    P.Nome,
 
    IV.Quantidade,
    IV.PrecoUnitario,
    IV.Total,
 
    V.ValorTotal
 
FROM Vendas V
 
INNER JOIN ItensVendas IV
ON V.CodigoVenda = IV.CodigoVenda
 
INNER JOIN Produtos P
ON P.CodigoProduto = IV.CodigoProduto;

Select * from NotaFiscal
------------------------------------------------------------------------------------------------------------------